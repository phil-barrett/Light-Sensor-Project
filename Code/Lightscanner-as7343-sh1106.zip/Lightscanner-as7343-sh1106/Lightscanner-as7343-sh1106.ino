#include <Adafruit_AS7343.h>
#include <Adafruit_AS7331.h>
#include <U8g2lib.h>
#include <Wire.h>

#define version "0.6"

// AS7343 spectral sensor
Adafruit_AS7343 as7343;

// AS7331 UV sensor
Adafruit_AS7331 as7331;

U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);
//U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);

int fontHeight;

int as7343Valid = 0;
int as7331Valid = 0;

uint8_t spectrum_map[12] = { 
      12,       ///< 405nm (violet)
       6,        ///< 425nm (violet-blue)
       0,        ///< 450nm (blue)
       7,        ///< 475nm (blue-cyan)
       8,        ///< 515nm (green)
      15,        ///< 550nm (green-yellow)
       1,        ///< 555nm (yellow-green)
       2,        ///< 600nm (orange)
       9,        ///< 640nm (red)
      13,        ///< 690nm (deep red)
      14,        ///< 745nm (near-IR)
       3         ///< 855nm (near-IR)
} ;
//  AS7343_CHANNEL_VIS_TL_0 = 4,  ///< Clear (top-left) cycle 1
//  AS7343_CHANNEL_VIS_BR_0 = 5,  ///< Clear (both-right) cycle 1
//  AS7343_CHANNEL_VIS_TL_1 = 10, ///< Clear (top-left) cycle 2
//  AS7343_CHANNEL_VIS_BR_1 = 11, ///< Clear (both-right) cycle 2
//  AS7343_CHANNEL_VIS_TL_2 = 16, ///< Clear (top-left) cycle 3
//  AS7343_CHANNEL_VIS_BR_2 = 17, ///< Clear (both-right) cycle 3

// spectral display max values (emprically derived)
#define UVMAX 2400
#define IRMAX 20000
#define LUXMAX 20000

//
//  is character ch in the list pointed to by setList
//
int inset(char ch, char *setList){
  while(*setList) {
    if(ch == *setList++) return 1;
  }
  return 0;
}

void setup() {
  int stCount = 0;
  Serial.begin(115200);
  while (!Serial) {
    delay(10); // Wait for Serial on native USB boards
    if(stCount++ > 100) break;
  }

  Serial.printf("\n\nLight Sensor Manager\nVer %s\nEnter ? for help\n", version);

  setupAS7343();
  setupAS7331();
 
  setupLCD();

}

void setupLCD(){
  //
  // initialize the LCD display
  //
  u8g2.begin();               // No error return (?!?)
  u8g2.clearBuffer();					// clear the internal memory
  
  // choose a suitable font
  u8g2.setFont(u8g2_font_ncenB08_tr);	
  //u8g2.setFont(u8g2_font_callite24_tr);
  //u8g2.setFont(u8g2_font_t0_15b_tn);
  //u8g2.setFont(u8g2_font_crox3cb_tr);
  fontHeight = u8g2.getMaxCharHeight();


}

void setupAS7343(){
  //
  // initialize the AS7343
  //
  if (!as7343.begin()) {
    Serial.println("Could not find AS7343 sensor!");
    return;
  }
  as7343Valid = 1;

  // Configure AS7343
  as7343.setGain(AS7343_GAIN_64X);
  as7343.setATIME(29);  // Integration cycles
  as7343.setASTEP(599); // Step size

  Serial.print("Integration time: ");
  Serial.print(as7343.getIntegrationTime());
  Serial.println(" ms");
}

void setupAS7331(){
  // 
  // initialize and configue the AS7331
  //
  if (!as7331.begin(&Wire)) {
    Serial.println("Could not find AS7331 sensor!");
    return;

    }
  int as7331Valid = 1;

  as7331.setMeasurementMode(AS7331_MODE_CMD);
  as7331.setGain(AS7331_GAIN_64X);
  as7331.setIntegrationTime(AS7331_TIME_64MS);



}

int uvSample = 1;
int irSample = 1;
int luxSample = 1;
char *cmd = "?culia";
int iterCount = 21;
uint16_t readings[18];

void executeCommand(char ch) {
  
  ch = tolower(ch);
  // Serial.printf("dbg: executeCommand [%c]\n", ch);

  switch(ch) { 
    case '?': 
              Serial.printf("Usage:\n    ?     print command list\n");
              Serial.printf(        "    c     Clear all settings\n");
              Serial.printf(        "    u[+-] Toggle UV setting\n");
              Serial.printf(        "    l[+-] Toggle visible light setting\n");
              Serial.printf(        "    i[+-] Toggle IR setting\n");
              Serial.printf(        "    a     Set all settings\n");
              break; 
    case 'c': // clear settings
              uvSample = 0;
              irSample = 0;
              luxSample = 0;
              Serial.printf("UV Sampling is %s\n", uvSample ? "on" : "off");
              Serial.printf("LUX Sampling is %s\n", luxSample ? "on" : "off");
              Serial.printf("IR Sampling is %s\n", irSample ? "on" : "off");
              break;
    case 'a': // set all
              uvSample = 1;
              irSample = 1;
              luxSample = 1;
              Serial.printf("UV Sampling is %s\n", uvSample ? "on" : "off");
              Serial.printf("LUX Sampling is %s\n", luxSample ? "on" : "off");
              Serial.printf("IR Sampling is %s\n", irSample ? "on" : "off");
              break;
    case 'u': // UV selection 
              ch = Serial.read();
              if(ch == '+') { 
                uvSample = 1; } 
              else {
                if(ch == '-') 
                  uvSample = 0;}
              Serial.printf("UV Sampling is %s\n", uvSample ? "on" : "off");
              break; 
    case 'l': // visible selection 
              ch = Serial.read();
              if(ch == '+') { 
                luxSample = 1; } 
              else {
                if(ch == '-') 
                  luxSample = 0;}
              Serial.printf("LUX Sampling is %s\n", luxSample ? "on" : "off");
              break; 
    case 'i': // UV selection 
              ch = Serial.read();
              if(ch == '+') { 
                irSample = 1; } 
              else {
                if(ch == '-') 
                  irSample = 0;}
              Serial.printf("IR Sampling is %s\n", irSample ? "on" : "off");
              break; 
    // default:         
  }  
  iterCount=21;
}

char ch, tempStr[40];
float uva, uvb, uvc;

void loop() {
  
  uint8_t i;
  

  while(Serial.available()) {
    ch = (char) tolower(Serial.read());
    if(inset(ch, cmd)) executeCommand(ch);
  }

  // Read all channels (starts measurement, waits, reads internally)
  if (!as7343.readAllChannels(readings)) {
    Serial.println("Read failed!");
  }

  as7331.oneShot_uWcm2(&uva, &uvb, &uvc);


  if(iterCount++>20) {
    if(luxSample) Serial.printf(" Visible");
    if(uvSample) Serial.printf("    UV");
    if(irSample) Serial.printf("       IR");
    Serial.printf("\n");
    // Serial.printf(" [ clear]     UVA     UVB     UVC 405nm 425nm 450nm 475nm 515nm 550nm 555nm 600nm 640nm 690nm 745nm 855nm\n");
    iterCount = 0;
  }

  i=0;

  if(luxSample) {
    Serial.printf("  %6d", readings[4]);
  }
  if(uvSample){
    Serial.printf("%8.2f", uva+uvb+uvc);
  }
  if(irSample){
    Serial.printf("  %6d", (readings[14] + readings[3])/2);  // average of 745nm and 855nm
  }
  Serial.printf("\n");

 /* Serial.printf(" [%6d]%8.2f%8.2f%8.2f%6d%6d%6d%6d%6d%6d%6d%6d%6d%6d%6d%6d\n",
    readings[4],  // "clear" reading
    uva, uvb, uvc,
    readings[spectrum_map[i++]],  // 405nm
    readings[spectrum_map[i++]],  // 425nm
    readings[spectrum_map[i++]],  // 450nm
    readings[spectrum_map[i++]],  // 475nm
    readings[spectrum_map[i++]],  // 515nm
    readings[spectrum_map[i++]],  // 550nm
    readings[spectrum_map[i++]],  // 555nm
    readings[spectrum_map[i++]],  // 600nm
    readings[spectrum_map[i++]],  // 640nm
    readings[spectrum_map[i++]],  // 690nm
    readings[spectrum_map[i++]],  // 745nm
    readings[spectrum_map[i++]] );// 855nm
*/
  displaySamplesLCD(); 
  /*
  sprintf(tempStr, "  %5d", readings[4]);
  u8g2.clearBuffer();			
  u8g2.drawStr(6,40, tempStr);
  u8g2.sendBuffer();
*/

  delay(2000);

}

// int scaleResult(int value, int range, int low, int high){


//}

#define BARHEIGHT 8
#define BARSTARTCOL 50
#define BARMAX (128-BARSTARTCOL-2)

void displaySamplesLCD(){
  int dispRow = 22;
  long luxMapped, uvMapped, irMapped;


  u8g2.clearBuffer();			
  u8g2.setDrawColor(1);

  if(luxSample) {
    //sprintf(tempStr, "Vis  %5d", readings[4]);
    sprintf(tempStr, "Vis");
    u8g2.drawStr(16, dispRow, tempStr);
    luxMapped = map(readings[4], 0, LUXMAX, 1, BARMAX);
    u8g2.drawBox( BARSTARTCOL,dispRow-BARHEIGHT+1, luxMapped, BARHEIGHT);
    dispRow += 15;
  }
  if(uvSample) {
    sprintf(tempStr, "UV");
    u8g2.drawStr(16,dispRow, tempStr);
    uvMapped = map((long) uva+uvb+uvc, 0, LUXMAX, 1, BARMAX);
    u8g2.drawBox( BARSTARTCOL,dispRow-BARHEIGHT+1, uvMapped, BARHEIGHT);
    dispRow += 15;
  }
  if(irSample) {
    //sprintf(tempStr, "IR    %5d", (readings[14] + readings[3])/2);
    sprintf(tempStr, "IR");
    u8g2.drawStr(16,dispRow, tempStr);
    irMapped = map((readings[14] + readings[3])/2, 0, LUXMAX, 1, BARMAX);
    u8g2.drawBox( BARSTARTCOL,dispRow-BARHEIGHT+1, irMapped, BARHEIGHT);

  }

u8g2.sendBuffer();
//Serial.printf("LuxMapped: %d\n", luxMapped);

}
