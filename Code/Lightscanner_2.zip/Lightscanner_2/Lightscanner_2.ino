#include <Adafruit_AS7343.h>
#include <Adafruit_AS7341.h>
#include <Adafruit_AS7331.h>
#include <Adafruit_BME280.h>

#include <U8g2lib.h>
#include <Wire.h>

#define version "1.78"

int setupAS7343();
int setupAS7331();
int setupAS7341();
int setupbme280();
void setupTriggers();

struct Sensors {
  uint8_t present, active;
  char *name;
  int (*sensorSetup)();

} sensorList[] = {
  { .name = "AS7343", .sensorSetup = setupAS7343 },
  { .name = "AS7331", .sensorSetup = setupAS7331 },
  { .name = "AS7341", .sensorSetup = setupAS7341 },
  { .name = "bme280", .sensorSetup = setupbme280 }
 // { 0, 0, "AS7331", setupAS7331 },
 // { 0, 0, "AS7341", setupAS7431 },
 // { 0, 0, "bme280", setupbme280 }
};
// AS7343 spectral sensor
Adafruit_AS7343 as7343;

// AS7341 spectral sensor
//Adafruit_AS7341 as7341;

// AS7331 UV sensor
Adafruit_AS7331 as7331;

// BME 280 Humidity sensor
Adafruit_BME280 bme280; // I2C

int fontHeight;

int as7343Valid = 0;
int as7331Valid = 0;

uint8_t spectrum_map[12] = { 
      12,       ///< 405nm (violet)
       6,        ///< 425nm (violet-blue)
       0,        ///< 450nm (blue)
       7,        ///< 475nm (blue-cyan)
       8,        ///< 515nm (green)
      15,        ///< 550nm (green-yellow)
       1,        ///< 555nm (yellow-green)
       2,        ///< 600nm (orange)
       9,        ///< 640nm (red)
      13,        ///< 690nm (deep red)
      14,        ///< 745nm (near-IR)
       3         ///< 855nm (near-IR)
} ;
//  AS7343_CHANNEL_VIS_TL_0 = 4,  ///< Clear (top-left) cycle 1
//  AS7343_CHANNEL_VIS_BR_0 = 5,  ///< Clear (both-right) cycle 1
//  AS7343_CHANNEL_VIS_TL_1 = 10, ///< Clear (top-left) cycle 2
//  AS7343_CHANNEL_VIS_BR_1 = 11, ///< Clear (both-right) cycle 2
//  AS7343_CHANNEL_VIS_TL_2 = 16, ///< Clear (top-left) cycle 3
//  AS7343_CHANNEL_VIS_BR_2 = 17, ///< Clear (both-right) cycle 3

// spectral display max values (emprically derived)
#define UVMAX 2400
#define IRMAX 20000
#define LUXMAX 20000

#define HEADERSIZE 2048
char headerText[HEADERSIZE];
char footerText[HEADERSIZE];

char headerDefault[] = "Sheet header\n";
char footerDefault[] = "Sheet footer\n";


//
//  is character ch in the list pointed to by setList
//
int inset(char ch, char *setList){
  while(*setList) {
    if(ch == *setList++) return 1;
  }
  return 0;
}

void setup() {
  int stCount = 0;
  Serial.begin(115200);
  while (!Serial) {
    delay(10); // Wait for Serial on native USB boards
    if(stCount++ > 100) break;
  }
  delay(1000);

  // init header and footer
  
  memcpy(headerText, headerDefault, strlen(headerDefault));
  memcpy(footerText, footerDefault, strlen(footerDefault));

  Serial.printf("\n\nLight Sensor Manager\nVer %s\nEnter ? for help\n", version);

  for(int j=0;j< sizeof(sensorList)/sizeof(Sensors);j++){
    sensorList[j].active = sensorList[j].present = sensorList[j].sensorSetup(); 
  }

  setupLCD();

  setupTriggers();
}

// select appropriate constructor for your display
//U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);
U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);
//U8G2_SSD1309_128X64_NONAME0_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);  // good for 1.5" display


void setupLCD(){
  //
  // initialize the LCD display
  //
  u8g2.setI2CAddress(0x3D * 2);  // comment out if display does not work
  u8g2.begin();               // No error return (?!?)
  u8g2.clearBuffer();					// clear the internal memory
  
  // choose a suitable font
  u8g2.setFont(u8g2_font_ncenB08_tr);	
  //u8g2.setFont(u8g2_font_callite24_tr);
  //u8g2.setFont(u8g2_font_t0_15b_tn);
  //u8g2.setFont(u8g2_font_crox3cb_tr);
  fontHeight = u8g2.getMaxCharHeight();


}

int setupAS7343(){
  //
  // initialize the AS7343
  //
  if (!as7343.begin()) {
    Serial.println("Could not find AS7343 sensor!");
    return 0;
  }
  as7343Valid = 1;

  // Configure AS7343
  as7343.setGain(AS7343_GAIN_64X);
  as7343.setATIME(29);  // Integration cycles
  as7343.setASTEP(599); // Step size

  Serial.print("Integration time: ");
  Serial.print(as7343.getIntegrationTime());
  Serial.println(" ms");
  return 1;
}

int  setupAS7331(){
  // 
  // initialize and configue the AS7331
  //
  if (!as7331.begin(&Wire)) {
    Serial.println("Could not find AS7331 sensor!");
    return 0;

    }
  int as7331Valid = 1;

  as7331.setMeasurementMode(AS7331_MODE_CMD);
  as7331.setGain(AS7331_GAIN_64X);
  as7331.setIntegrationTime(AS7331_TIME_64MS);
  return 1;

}
// AS7341 spectral sensor
Adafruit_AS7341 as7341;

int setupAS7341(){
    if (!as7341.begin()){
      return 0;
  }
 
  as7341.setATIME(100);
  as7341.setASTEP(999);
  as7341.setGain(AS7341_GAIN_256X);
  return 1;

}

int setupbme280(){

  return bme280.begin();

}

int uvSample = 1;
int uvaSample = 0;
int uvbSample = 0;
int uvcSample = 0;
int irSample = 1;
int ir745Sample = 0;
int ir855Sample = 0;
int luxSample = 1;
int iterCount = 21;
uint16_t readings[18];
uint8_t continuousMode = 1;  // 0 for triggered mode, 1 for continuous mode

char ch, tempStr[40];
float uva, uvb, uvc;


//
//  Setup the trigger inputs.
//  Pulled high.  To trigger, they need to
//  to be pulled to zero.  Can use the screw
//  terminals on the RP23U5XBB (open collector). 
//  M62 turns on, M63 turns off.
//  If using digital outputs (pin headers) on
//  the RP23U5XBB, M62 turns off, M63 turns on.
//
#define SAMPLEPIN 19
#define LINEPIN 18
#define DOCPIN 17
int samplePrev = 1;
int linePrev = 1;
int docPrev = 1;
void setupTriggers(){

  pinMode(SAMPLEPIN, INPUT_PULLUP); // Aux 0
  pinMode(LINEPIN, INPUT_PULLUP);   // Aux 1
  pinMode(DOCPIN, INPUT_PULLUP);    // Aux 2

}

// finite state machine
// for triggers
#define NOCH 0
#define ONACT 1
#define OFFACT 2
int triggerArray[2][2] = {
  // prv  0       1       // pin
  {       NOCH,   ONACT },//  0
  {       OFFACT, NOCH  } //  1
};
 
void triggerTest(){
  int a, b;

  // send sensor sample
  b = digitalRead(SAMPLEPIN);
  a = triggerArray[b][samplePrev];
  switch(a) {
    case NOCH:    break;
    case OFFACT:
                  samplePrev = 1; // set to off
                  break;
    case ONACT:   samplePrev  = 0; // set to on
                  sendSampleData();
                  break;
  }

  // send doc data
  switch(triggerArray[digitalRead(DOCPIN)][docPrev]) {
  case NOCH:    break;
  case OFFACT:
                docPrev = 1; // set to off
                sendDocEnd();
                break;
  case ONACT:   docPrev  = 0; // set to on
                sendDocStart();
                break;
  }

  // send line data
  switch(triggerArray[digitalRead(LINEPIN)][linePrev]) {
  case NOCH:    break;
  case OFFACT:
                linePrev = 1; // set to off
                sendLineEnd();
                break;
  case ONACT:   linePrev  = 0; // set to on
                sendLineStart();
                break;
  }
}


void sendSampleData(){

    // send sample
    if(luxSample) {
      Serial.printf("\"%d\",", readings[4]);
    }
    if(uvSample){
      Serial.printf("\"%f\",", uva+uvb+uvc);
    }
    if(uvaSample){
      Serial.printf("\"%f\",", uva);
    }
    if(uvbSample){
      Serial.printf("\"%f\",", uvb);
    }
    if(uvcSample){
      Serial.printf("\"%f\",", uvc);
    }
    if(irSample){
      Serial.printf("\"%d\",", (readings[14] + readings[3])/2);  // average of 745nm and 855nm
    }
    if(ir745Sample){
      Serial.printf("\"%d\",", readings[14]);  // 745nm
    }
    if(ir855Sample){
      Serial.printf("\"%d\",", readings[3]);  // 855nm
    }
  
}

void sendLineStart(){
  // nothing to send
}

void sendLineEnd(){
  Serial.printf("\n");  // simple new line
}

void sendDocStart(){
  Serial.printf("##################################################\n");
  Serial.printf("%s", headerText);
  displaySampleStatus();
}

void sendDocEnd(){
    Serial.printf("%s", footerText);
    Serial.printf("##################################################\n");

}

char *pmList = "-+";
// +- helper function
void pmFunct(char ch, int *option){
  char *pml; int i=0;

  pml = pmList;
  while(*pml)  {
    if(*pml++ == ch) {
      *option = i;
      return;
    }
    i++;
  }
}

#define CR 0x0D
#define LF 0x0A
#define SLASH 0x2F
void executeCommand(char ch) {
  char *htp, *ltp;
  ch = tolower(ch);
  // Serial.printf("dbg: executeCommand [%c]\n", ch);

  switch(ch) { 
    case '?': 
              Serial.printf("Usage:\n    ?      print command list\n");
              Serial.printf("    c      Clear all settings\n");
              Serial.printf("    u[+-]  Toggle UV setting\n");
              Serial.printf("    ua[+-] Toggle UVA setting\n");
              Serial.printf("    ub[+-] Toggle UVB setting\n");
              Serial.printf("    uc[+-] Toggle UVC setting\n");
              Serial.printf("    l[+-]  Toggle visible (LUX) light setting\n");
              Serial.printf("    i[+-]  Toggle IR setting\n");
              Serial.printf("    i7[+-] Toggle 745nm IR setting\n");
              Serial.printf("    i8[+-] Toggle 855nm IR setting\n");
              Serial.printf("    a      Set all settings\n");
              Serial.printf("    t[+-]  Triggered mode on/off\n");
              Serial.printf("    r[rmv] display rotation. no argument - restore to default rotation\n");
              Serial.printf("           r - rotate 180, m - mirror, v - mirror and flip vertical\n");
              Serial.printf("    s      display all sample status\n");
              Serial.printf("    v      display version number\n");
              break; 
    case 'c': // clear settings
              uvSample = 0;
              irSample = 0;
              luxSample = 0;
              Serial.printf("UV Sampling is %s\n", uvSample ? "on" : "off");
              Serial.printf("LUX Sampling is %s\n", luxSample ? "on" : "off");
              Serial.printf("IR Sampling is %s\n", irSample ? "on" : "off");
              break;
    case 'a': // set all
              uvSample = 1;
              irSample = 1;
              luxSample = 1;
              Serial.printf("UV Sampling is %s\n", uvSample ? "on" : "off");
              Serial.printf("LUX Sampling is %s\n", luxSample ? "on" : "off");
              Serial.printf("IR Sampling is %s\n", irSample ? "on" : "off");
              break;
    case 'u': // UV selection 
              pmFunct(ch = Serial.read(), &uvSample);
              if(!inset(ch, "abc")) {
                Serial.printf("UV Sampling is %s\n", uvSample ? "on" : "off");
                break; } 
              else {
                uvSample = 0;
                switch(ch) {
                  case 'a': pmFunct(Serial.read(), &uvaSample);
                            break;

                  case 'b': pmFunct(Serial.read(), &uvbSample);
                            break;

                  case 'c': pmFunct(Serial.read(), &uvcSample);
                            break;
                 };
                 Serial.printf("UVA is %s, UVB is %s, UVC is %s\n", uvaSample ? "on" : "off", uvbSample  ? "on" : "off", uvcSample  ? "on" : "off" );
              }
              break; 
    case 'l': // visible selection 
              pmFunct( Serial.read(), &luxSample);
              Serial.printf("LUX Sampling is %s\n", luxSample ? "on" : "off");
              break; 
    case 'i': // UV selection 
              pmFunct( ch = Serial.read(), &irSample);
              if(inset(ch, "78")) {
                switch (ch) {
                  case '7': pmFunct(Serial.read(), &ir745Sample);
                            break;
                  case '8': pmFunct(Serial.read(), &ir855Sample);
                            break;
                };
                irSample = 0; // turn off composite NIR
                Serial.printf("NIR 745nm Sampling is %s, NIR 855nm Sampling is %s\n",
                  ir745Sample ? "on" : "off",
                  ir855Sample ? "on": "off" );
                break;
              }
              Serial.printf("IR Sampling is %s\n", irSample ? "on" : "off");
              break; 
    case 'v': Serial.printf("Version %s\n", version);
              break;
    case 't': // triggered mode or continuous mode
              ch = Serial.read();
              if(ch == '+') { 
                continuousMode = 0; } 
              else {
                if(ch == '-') 
                 continuousMode = 1;}
              Serial.printf("Triggered Mode is %s\n", continuousMode ? "off" : "on");
              break;
    case 'h': // load header text
              htp = headerText;
              while((ch=Serial.read()) != 0x0A)  {
                Serial.printf("[%x]", ch);
                *htp++ = ch;
              }
              *htp='\0';
              ltp = htp = headerText;
              while(*ltp != '\0') {
                if(*ltp != SLASH) {
                  *htp = *ltp++;
                  htp++;
                } else {
                  ltp++;
                  if(*ltp == 'n') *htp = CR;
                  htp++;
                }
              }
              *htp = 0;
              htp = headerText;
              while(*htp!= '\0') Serial.printf("[%2x]", *htp++);
              Serial.printf( headerText);
              Serial.printf("\n");
              break;
    case 'f': // load header text
              htp = footerText;
              while((ch=Serial.read()) != 0x0A) *htp++ = ch;
              *htp='\0';
              break;
    case 'r': // load header text
              ch = Serial.read();
              switch(ch) { 
                case 'r':
                u8g2.setDisplayRotation(U8G2_R2);
                break;
                case 'm':
                  u8g2.setDisplayRotation(U8G2_MIRROR);
                  break;
                case 'v':
                  u8g2.setDisplayRotation(U8G2_MIRROR_VERTICAL);
                  break;
                default:
                  u8g2.setDisplayRotation(U8G2_R0);
              }
              break;
    case 's': displaySampleStatus();
              break;
    // default:         
  }  
  iterCount=21;
}

struct sampleStat {
  char *name;
  int *sampleVar;
};
sampleStat sampleStatus[8] = {
  {"UA Sampling", &uvSample },
  {"UVA Sampling", &uvaSample },
  {"UVB Sampling", &uvbSample },
  {"UVC Sampling", &uvcSample },
  {"NIR Sampling", &irSample },
  {"NIR 745nm Sampling", &ir745Sample },
  {"NIR 855nm Sampling", &ir855Sample },
  {"Vis Sampling", &luxSample }
};
void displaySampleStatus(){
  for(int i=0;i< sizeof(sampleStatus)/sizeof(sampleStatus[0]); i++) Serial.printf("%s is %s\n", sampleStatus[i].name, *sampleStatus[i].sampleVar ? "on" : "off" );
}


// update periods in mS
// LCD period must be < than COM period
#define LCDUPDATEPERIOD 100
#define COMUPDATEPERIOD 2000

void comUpdate(){

    if(iterCount++>20) {
      // print header
      if(luxSample) Serial.printf(" Visible");
      if(uvSample) Serial.printf("    UV");
      if(irSample) Serial.printf("       IR");
      Serial.printf("\n");
      // Serial.printf(" [ clear]     UVA     UVB     UVC 405nm 425nm 450nm 475nm 515nm 550nm 555nm 600nm 640nm 690nm 745nm 855nm\n");
      iterCount = 0;
    }

    if(luxSample) {
      Serial.printf("  %6d", readings[4]);
    }
    if(uvSample){
      Serial.printf("%8.2f", uva+uvb+uvc);
    }
    if(irSample){
      Serial.printf("  %6d", (readings[14] + readings[3])/2);  // average of 745nm and 855nm
    }
    Serial.printf("\n");
  
}

char *cmd = "?culiavthfrs"; // command list 
uint32_t  LCDUpdateMS = 0, comUpdateMS = 0, currentMS = 0;

// main loop
void loop() {

  // check for serial input
  while(Serial.available()) {
    ch = (char) tolower(Serial.read());
    if(inset(ch, cmd)) executeCommand(ch);
  }

  currentMS = millis();
  // handle timer rollover
  if(currentMS< LCDUpdateMS) LCDUpdateMS = comUpdateMS = currentMS;

  // LCD Update period expired?
  if(currentMS > (LCDUpdateMS+LCDUPDATEPERIOD)){ 
    LCDUpdateMS = currentMS;

    // Read all channels (starts measurement, waits, reads internally)
    if (!as7343.readAllChannels(readings)) {
      Serial.println("Read failed!");
    }
    as7331.oneShot_uWcm2(&uva, &uvb, &uvc);

    displaySamplesLCD(); 

  }

  if(continuousMode) {
    // COM update period expired?
    if(millis() > (comUpdateMS+COMUPDATEPERIOD)) {
      comUpdateMS = millis();
      comUpdate();
 
      delay(1);
    }
  } else {
    // triggered mode
    triggerTest();
    
  } 

}

#define BARHEIGHT 8
#define BARSTARTCOL 50
#define BARMAX (128-BARSTARTCOL-2)

void drawInvertedText( int x, int y, int invert, char * txt ){
  int fieldWidth;
 
  u8g2.setDrawColor(1);
  if(invert==0){
    fieldWidth = u8g2.getStrWidth(txt);
    u8g2.drawBox(x-1, y-fontHeight+2, fieldWidth+2, fontHeight);
    u8g2.setDrawColor(0);
  }
  u8g2.drawStr(x, y, txt);
  u8g2.setDrawColor(1);

}

void displaySamplesLCD(){
  int dispRow = 16;
  long luxMapped, uvMapped, irMapped;


  u8g2.clearBuffer();			
  u8g2.setDrawColor(1);

  //sprintf(tempStr, "Vis  %5d", readings[4]);
  sprintf(tempStr, "Vis");
  u8g2.drawStr(16, dispRow, tempStr);
  luxMapped = map(readings[4], 0, LUXMAX, 1, BARMAX);
  u8g2.drawBox( BARSTARTCOL,dispRow-BARHEIGHT-1, luxMapped, BARHEIGHT);
  if(luxSample) {
    u8g2.drawTriangle(4, dispRow-BARHEIGHT, 12, dispRow-(BARHEIGHT/2), 4, dispRow);
  }
  dispRow += 15;

  // sum the UV bands
  sprintf(tempStr, "UV");
  u8g2.drawStr(16,dispRow, tempStr);
  uvMapped = map((long) uva+uvb+uvc, 0, LUXMAX, 1, BARMAX);
  u8g2.drawBox( BARSTARTCOL,dispRow-BARHEIGHT-1, uvMapped, BARHEIGHT);
  if(uvSample) {
    u8g2.drawTriangle(4, dispRow-BARHEIGHT, 12, dispRow-(BARHEIGHT/2), 4, dispRow);
  }
  dispRow += 15;

  // average the 2 near IR bands
  //sprintf(tempStr, "IR    %5d", (readings[14] + readings[3])/2);
  sprintf(tempStr, "IR");
  u8g2.drawStr(16,dispRow, tempStr);
  irMapped = map((readings[14] + readings[3])/2, 0, LUXMAX, 1, BARMAX);
  u8g2.drawBox( BARSTARTCOL,dispRow-BARHEIGHT-1, irMapped, BARHEIGHT);
  if(irSample) {
    u8g2.drawTriangle(4, dispRow-BARHEIGHT, 12, dispRow-(BARHEIGHT/2), 4, dispRow);
  }

  // show status of input pins
  // invert text if pin is inverted
  dispRow = 63;
  drawInvertedText(6, dispRow, digitalRead(SAMPLEPIN), "Sample");
  drawInvertedText(55, dispRow, digitalRead(LINEPIN), "Line");
  drawInvertedText( 90, dispRow, digitalRead(DOCPIN), "Doc");

  u8g2.sendBuffer(); // update the LCD display

}
